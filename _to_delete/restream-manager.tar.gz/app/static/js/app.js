/* Restream Manager - dashboard behaviour.
 *
 * Everything talks to the JSON API; the HTML is only ever refreshed through
 * HTMX partials, so no full page reload is needed while streams are running.
 */
(() => {
  "use strict";

  // ---------------------------------------------------------------- utils
  const toastHost = () => document.getElementById("toasts");

  function toast(message, variant = "secondary") {
    const host = toastHost();
    if (!host) {
      return;
    }
    const el = document.createElement("div");
    el.className = `toast align-items-center text-bg-${variant} border-0`;
    el.setAttribute("role", "alert");
    el.innerHTML = `
      <div class="d-flex">
        <div class="toast-body">${escapeHtml(message)}</div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
      </div>`;
    host.appendChild(el);
    const instance = new bootstrap.Toast(el, { delay: 5000 });
    instance.show();
    el.addEventListener("hidden.bs.toast", () => el.remove());
  }

  function escapeHtml(value) {
    const div = document.createElement("div");
    div.textContent = value === undefined || value === null ? "" : String(value);
    return div.innerHTML;
  }

  async function api(path, options = {}) {
    const response = await fetch(path, {
      headers: { "Content-Type": "application/json" },
      ...options,
    });
    let payload = null;
    try {
      payload = await response.json();
    } catch (err) {
      payload = null;
    }
    if (!response.ok) {
      const detail =
        (payload && (payload.detail || payload.error)) ||
        `${response.status} ${response.statusText}`;
      throw new Error(typeof detail === "string" ? detail : JSON.stringify(detail));
    }
    return payload;
  }

  function formData(form) {
    const data = {};
    new FormData(form).forEach((value, key) => {
      data[key] = value;
    });
    form.querySelectorAll('input[type="checkbox"]').forEach((box) => {
      data[box.name] = box.checked;
    });
    return data;
  }

  function selectedIds() {
    return Array.from(document.querySelectorAll(".row-select:checked")).map((box) =>
      Number(box.value)
    );
  }

  function json(value) {
    return JSON.stringify(value, null, 2);
  }

  // ------------------------------------------------------- channel actions
  document.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-action]");
    if (!button) {
      return;
    }
    event.preventDefault();
    const { action, id, confirm: confirmText } = button.dataset;
    if (confirmText && !window.confirm(confirmText)) {
      return;
    }
    button.disabled = true;
    try {
      if (action === "delete") {
        await api(`/api/channels/${id}`, { method: "DELETE" });
        toast("Channel deleted", "success");
        window.location.href = "/";
        return;
      }
      if (action === "test") {
        const result = await api(`/api/channels/${id}/test`, { method: "POST" });
        renderTestResult(result);
        toast(result.ok ? "Source is reachable" : `Test failed: ${result.error}`,
              result.ok ? "success" : "danger");
        return;
      }
      const result = await api(`/api/channels/${id}/${action}`, { method: "POST" });
      if (result && result.ok === false) {
        toast(result.error || "Action failed", "danger");
      } else {
        toast(`${action} requested`, "success");
      }
    } catch (err) {
      toast(err.message, "danger");
    } finally {
      button.disabled = false;
    }
  });

  function renderTestResult(result) {
    const host = document.getElementById("test-result");
    if (!host) {
      return;
    }
    const probe = result.probe || {};
    const stream = result.stream || {};
    host.innerHTML = `
      <div class="alert ${result.ok ? "alert-success" : "alert-danger"}">
        <div class="fw-semibold mb-1">
          Source reachable: ${result.ok ? "YES" : "NO"}
        </div>
        <div class="smaller">
          ${result.ok ? `
            Video codec: ${escapeHtml(probe.video_codec || "-")} ·
            Audio codec: ${escapeHtml(probe.audio_codec || "-")} ·
            Resolution: ${escapeHtml(probe.resolution || "-")} ·
            Probe time: ${escapeHtml(probe.elapsed_ms || 0)} ms<br>
            URL: <code>${escapeHtml(stream.url || "")}</code>
          ` : escapeHtml(result.error || "unknown error")}
        </div>
      </div>`;
  }

  // ---------------------------------------------------------- bulk actions
  document.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-bulk]");
    if (!button) {
      return;
    }
    event.preventDefault();
    const kind = button.dataset.bulk;
    const confirmText = button.dataset.confirm;
    if (confirmText && !window.confirm(confirmText)) {
      return;
    }
    button.disabled = true;
    try {
      if (kind === "sync") {
        const providerId = button.dataset.id ? Number(button.dataset.id) : null;
        const result = await api("/api/sync", {
          method: "POST",
          body: json({ provider_id: providerId }),
        });
        const added = (result.added || []).length;
        const missing = (result.missing || []).length;
        const errors = result.errors || [];
        toast(
          `Sync complete: ${added} new, ${(result.updated || []).length} updated, ${missing} missing`,
          errors.length ? "warning" : "success"
        );
        errors.forEach((message) => toast(message, "danger"));
        if (added || missing) {
          setTimeout(() => window.location.reload(), 1200);
        }
        return;
      }

      const map = {
        "start-all": { action: "start", ids: [] },
        "stop-all": { action: "stop", ids: [] },
        "restart-selected": { action: "restart", ids: selectedIds() },
        "refresh-selected": { action: "refresh", ids: selectedIds() },
      };
      const spec = map[kind];
      if (!spec) {
        return;
      }
      if (kind.endsWith("selected") && spec.ids.length === 0) {
        toast("Select at least one channel first", "warning");
        return;
      }
      const result = await api("/api/channels/bulk", {
        method: "POST",
        body: json({ action: spec.action, channel_ids: spec.ids }),
      });
      toast(`Done (${result.started ?? result.stopped ?? result.count ?? 0} channels)`, "success");
    } catch (err) {
      toast(err.message, "danger");
    } finally {
      button.disabled = false;
    }
  });

  // select-all checkbox
  document.addEventListener("change", (event) => {
    if (event.target.id !== "select-all") {
      return;
    }
    document.querySelectorAll(".row-select").forEach((box) => {
      box.checked = event.target.checked;
    });
  });

  // language switcher
  document.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-lang]");
    if (!button) {
      return;
    }
    event.preventDefault();
    try {
      await api("/api/settings", {
        method: "POST",
        body: json({ values: { ui_language: button.dataset.lang } }),
      });
      window.location.reload();
    } catch (err) {
      toast(err.message, "danger");
    }
  });

  // copy-to-clipboard
  document.addEventListener("click", async (event) => {
    const button = event.target.closest("[data-copy]");
    if (!button) {
      return;
    }
    event.preventDefault();
    try {
      await navigator.clipboard.writeText(button.dataset.copy);
      toast("Copied to clipboard", "success");
    } catch (err) {
      toast("Clipboard not available in this browser", "warning");
    }
  });

  // --------------------------------------------------------- channel forms
  const createForm = document.getElementById("channel-form");
  if (createForm) {
    createForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const payload = formData(createForm);
      payload.provider_id = payload.provider_id ? Number(payload.provider_id) : null;
      try {
        await api("/api/channels", { method: "POST", body: json(payload) });
        toast("Channel created", "success");
        window.location.reload();
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }

  // ------------------------------------------------------------ bulk add
  const bulkForm = document.getElementById("bulk-form");
  if (bulkForm) {
    const previewHost = document.getElementById("bulk-preview-output");

    function bulkPayload() {
      const data = formData(bulkForm);
      return {
        text: data.text || "",
        provider_id: data.provider_id ? Number(data.provider_id) : null,
        stream_mode: data.stream_mode || "copy",
        stream_key_prefix: data.stream_key_prefix || "",
        enabled: Boolean(data.enabled),
        auto_start: false,
      };
    }

    function renderPreview(result) {
      if (!result.count) {
        previewHost.innerHTML = `<div class="alert alert-warning py-2 mb-0 smaller">
          ${escapeHtml((result.errors || ["nothing to import"]).join(" · "))}
        </div>`;
        return;
      }
      const rows = result.entries
        .map(
          (entry) => `<tr>
            <td>${escapeHtml(entry.name)}</td>
            <td><span class="badge text-bg-${entry.kind === "media" ? "success" : "info"}">${entry.kind}</span></td>
            <td class="text-break smaller">${escapeHtml(entry.resolve_url || entry.input_url)}</td>
            <td class="smaller">${escapeHtml(entry.stream_key || "-")}</td>
          </tr>`
        )
        .join("");
      previewHost.innerHTML = `
        <div class="alert alert-secondary py-2 smaller mb-2">
          ${result.count} channel(s) parsed${result.duplicates ? `, ${result.duplicates} duplicate(s) dropped` : ""}
          ${(result.errors || []).length ? `<br><span class="text-warning">${escapeHtml(result.errors.join(" · "))}</span>` : ""}
        </div>
        <div class="table-responsive" style="max-height: 260px; overflow-y: auto;">
          <table class="table table-sm smaller mb-0">
            <thead><tr><th>Name</th><th>Type</th><th>URL</th><th>Key</th></tr></thead>
            <tbody>${rows}</tbody>
          </table>
        </div>`;
    }

    const previewButton = document.getElementById("bulk-preview");
    if (previewButton) {
      previewButton.addEventListener("click", async () => {
        try {
          renderPreview(
            await api("/api/channels/preview-list", {
              method: "POST",
              body: json(bulkPayload()),
            })
          );
        } catch (err) {
          toast(err.message, "danger");
        }
      });
    }

    const fileButton = document.getElementById("bulk-file-btn");
    const fileInput = document.getElementById("bulk-file");
    if (fileButton && fileInput) {
      fileButton.addEventListener("click", () => fileInput.click());
      fileInput.addEventListener("change", async () => {
        const file = fileInput.files[0];
        if (!file) {
          return;
        }
        try {
          bulkForm.querySelector('[name="text"]').value = await file.text();
          previewButton?.click();
          toast(`Loaded ${file.name}`, "secondary");
        } catch (err) {
          toast(err.message, "danger");
        } finally {
          fileInput.value = "";
        }
      });
    }

    bulkForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      try {
        const result = await api("/api/channels/import-list", {
          method: "POST",
          body: json(bulkPayload()),
        });
        const created = (result.created || []).length;
        if (!created) {
          toast(
            (result.errors || []).join(" · ") || "No channels were created",
            "warning"
          );
          return;
        }
        toast(
          `Created ${created} channel(s)${result.skipped ? `, skipped ${result.skipped} duplicate(s)` : ""}`,
          "success"
        );
        (result.errors || []).forEach((message) => toast(message, "warning"));
        setTimeout(() => window.location.reload(), 1000);
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }

  const editForm = document.getElementById("channel-edit-form");
  if (editForm) {
    editForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const payload = formData(editForm);
      payload.provider_id = payload.provider_id ? Number(payload.provider_id) : null;
      try {
        await api(`/api/channels/${editForm.dataset.id}`, {
          method: "PUT",
          body: json(payload),
        });
        toast("Channel saved", "success");
        window.location.reload();
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }

  // ------------------------------------------------------------- providers
  const providerModalEl = document.getElementById("providerModal");
  const providerForm = document.getElementById("provider-form");
  const providerTypes = readJson("provider-types") || [];
  const providerData = readJson("provider-data") || [];
  const providerExamples = readJson("provider-examples") || {};

  function readJson(id) {
    const node = document.getElementById(id);
    if (!node) {
      return null;
    }
    try {
      return JSON.parse(node.textContent);
    } catch (err) {
      return null;
    }
  }

  function schemaFor(type) {
    const entry = providerTypes.find((item) => item.type === type);
    return entry ? entry.schema || [] : [];
  }

  function getPath(object, path) {
    return path.split(".").reduce((node, key) => (node && typeof node === "object" ? node[key] : undefined), object);
  }

  function setPath(object, path, value) {
    const parts = path.split(".");
    let node = object;
    parts.slice(0, -1).forEach((key) => {
      if (typeof node[key] !== "object" || node[key] === null) {
        node[key] = {};
      }
      node = node[key];
    });
    node[parts[parts.length - 1]] = value;
  }

  function renderProviderFields(type, config) {
    const host = document.getElementById("provider-fields");
    if (!host) {
      return;
    }
    const schema = schemaFor(type);
    if (!schema.length) {
      host.innerHTML = `<div class="col-12 text-secondary smaller">
        This provider type needs no configuration - add channels and paste a URL on each one.
      </div>`;
      return;
    }
    host.innerHTML = schema
      .map((field) => {
        const current = getPath(config, field.key);
        const value = current === undefined || current === null ? (field.default ?? "") : current;
        const help = field.help ? `<div class="form-text">${escapeHtml(field.help)}</div>` : "";
        const width = field.type === "json" ? "col-12" : "col-md-4";
        // Placeholders show the expected shape without pre-filling anything.
        const ph = field.placeholder
          ? ` placeholder="${escapeHtml(field.placeholder)}"`
          : "";
        if (field.type === "bool") {
          return `<div class="col-md-4">
            <div class="form-check mt-4">
              <input class="form-check-input" type="checkbox" data-config="${field.key}"
                     id="cfg-${field.key}" ${value ? "checked" : ""}>
              <label class="form-check-label" for="cfg-${field.key}">${escapeHtml(field.label)}</label>
            </div>${help}
          </div>`;
        }
        if (field.type === "choice") {
          const options = (field.choices || [])
            .map((choice) => `<option value="${escapeHtml(choice)}" ${choice === value ? "selected" : ""}>${escapeHtml(choice)}</option>`)
            .join("");
          return `<div class="${width}">
            <label class="form-label">${escapeHtml(field.label)}</label>
            <select class="form-select" data-config="${field.key}">${options}</select>${help}
          </div>`;
        }
        if (field.type === "json") {
          const text = typeof value === "object" ? JSON.stringify(value, null, 2) : String(value || "");
          return `<div class="${width}">
            <label class="form-label">${escapeHtml(field.label)}</label>
            <textarea class="form-control font-monospace" rows="3" data-config="${field.key}"
                      data-json="1"${ph}>${escapeHtml(text)}</textarea>${help}
          </div>`;
        }
        const inputType = field.type === "number" ? "number" : "text";
        const required = field.required ? " required" : "";
        return `<div class="${width}">
          <label class="form-label">
            ${escapeHtml(field.label)}
            ${field.required ? '<span class="text-danger">*</span>' : ""}
          </label>
          <input class="form-control" type="${inputType}" data-config="${field.key}"
                 value="${escapeHtml(value)}"${ph}${required}>${help}
        </div>`;
      })
      .join("");
  }

  function collectConfig() {
    const raw = providerForm.querySelector('[name="config_json"]');
    if (raw && raw.value.trim()) {
      try {
        return JSON.parse(raw.value);
      } catch (err) {
        throw new Error("Raw JSON configuration is not valid JSON");
      }
    }
    const config = {};
    providerForm.querySelectorAll("[data-config]").forEach((input) => {
      const key = input.dataset.config;
      let value;
      if (input.type === "checkbox") {
        value = input.checked;
      } else if (input.dataset.json) {
        const text = input.value.trim();
        if (!text) {
          return;
        }
        try {
          value = JSON.parse(text);
        } catch (err) {
          throw new Error(`${key} must be valid JSON`);
        }
      } else if (input.type === "number") {
        value = input.value === "" ? undefined : Number(input.value);
      } else {
        value = input.value.trim();
      }
      if (value === "" || value === undefined) {
        return;
      }
      setPath(config, key, value);
    });
    return config;
  }

  function openProvider(provider) {
    if (!providerForm) {
      return;
    }
    providerForm.reset();
    // An example has no id, so saving it creates a new provider.
    providerForm.querySelector('[name="id"]').value =
      provider && provider.id ? provider.id : "";
    providerForm.querySelector('[name="name"]').value = provider ? provider.name : "";
    providerForm.querySelector('[name="type"]').value = provider ? provider.type : providerTypes[0]?.type || "manual";
    providerForm.querySelector('[name="enabled"]').checked = provider ? provider.enabled : true;
    providerForm.querySelector('[name="is_default"]').checked = provider ? provider.is_default : false;
    const raw = providerForm.querySelector('[name="config_json"]');
    if (raw) {
      raw.value = "";
    }
    renderProviderFields(
      providerForm.querySelector('[name="type"]').value,
      provider ? provider.config || {} : {}
    );
    new bootstrap.Modal(providerModalEl).show();
  }

  document.addEventListener("click", (event) => {
    if (event.target.closest("[data-provider-new]")) {
      event.preventDefault();
      openProvider(null);
    }
    const editButton = event.target.closest("[data-provider-edit]");
    if (editButton) {
      event.preventDefault();
      const id = Number(editButton.dataset.providerEdit);
      openProvider(providerData.find((item) => item.id === id) || null);
    }
  });

  const typeSelect = document.getElementById("provider-type");
  if (typeSelect) {
    typeSelect.addEventListener("change", () => renderProviderFields(typeSelect.value, {}));
  }

  // "Use this example" on a card, and "Fill in the example" inside the modal.
  function applyExample(type) {
    const example = providerExamples[type];
    if (!example) {
      toast(`No example available for ${type}`, "warning");
      return;
    }
    openProvider({
      id: "",
      name: example.name,
      type: example.type,
      enabled: true,
      is_default: providerData.length === 0,
      config: example.config,
    });
    toast("Example loaded - edit the values, then press Save provider", "secondary");
  }

  document.addEventListener("click", (event) => {
    const card = event.target.closest("[data-provider-example]");
    if (card) {
      event.preventDefault();
      applyExample(card.dataset.providerExample);
    }
  });

  const loadExample = document.getElementById("load-example");
  if (loadExample) {
    loadExample.addEventListener("click", () => {
      const type = typeSelect ? typeSelect.value : "http_json";
      const example = providerExamples[type];
      if (!example) {
        toast(`No example available for ${type}`, "warning");
        return;
      }
      // Keep whatever the operator already typed in the name field.
      const nameInput = providerForm.querySelector('[name="name"]');
      if (nameInput && !nameInput.value.trim()) {
        nameInput.value = example.name;
      }
      const raw = providerForm.querySelector('[name="config_json"]');
      if (raw) {
        raw.value = "";
      }
      renderProviderFields(type, example.config);
      toast("Example values filled in", "secondary");
    });
  }

  if (providerForm) {
    providerForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = formData(providerForm);
      let config;
      try {
        config = collectConfig();
      } catch (err) {
        toast(err.message, "danger");
        return;
      }
      const payload = {
        name: data.name,
        type: data.type,
        enabled: Boolean(data.enabled),
        is_default: Boolean(data.is_default),
        config,
      };
      ["username", "password", "token", "cookie"].forEach((key) => {
        if (data[key]) {
          payload[key] = data[key];
        }
      });
      const id = data.id;
      try {
        if (id) {
          await api(`/api/providers/${id}`, { method: "PUT", body: json(payload) });
        } else {
          await api("/api/providers", { method: "POST", body: json(payload) });
        }
        toast("Provider saved", "success");
        window.location.reload();
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }

  document.addEventListener("click", async (event) => {
    const deleteButton = event.target.closest("[data-provider-delete]");
    if (deleteButton) {
      event.preventDefault();
      if (!window.confirm(deleteButton.dataset.confirm || "Delete this provider?")) {
        return;
      }
      try {
        await api(`/api/providers/${deleteButton.dataset.providerDelete}`, { method: "DELETE" });
        toast("Provider deleted", "success");
        window.location.reload();
      } catch (err) {
        toast(err.message, "danger");
      }
      return;
    }

    const testButton = event.target.closest("[data-provider-test]");
    if (!testButton) {
      return;
    }
    event.preventDefault();
    const kind = testButton.dataset.providerTest;
    const id = testButton.dataset.id;
    const host = document.getElementById(`provider-result-${id}`);
    testButton.disabled = true;
    try {
      if (kind === "resolve") {
        const modal = document.getElementById("resolveModal");
        modal.dataset.providerId = id;
        new bootstrap.Modal(modal).show();
        return;
      }
      const endpoint = kind === "auth" ? "test-auth" : "test-channels";
      const result = await api(`/api/providers/${id}/${endpoint}`, { method: "POST" });
      if (host) {
        host.innerHTML = result.ok
          ? `<div class="alert alert-success py-2 mb-0">${
              kind === "auth"
                ? "Login Successful"
                : `${result.count} channels found: ` +
                  escapeHtml((result.sample || []).map((c) => c.name).slice(0, 5).join(", "))
            }</div>`
          : `<div class="alert alert-danger py-2 mb-0">${escapeHtml(result.error)}</div>`;
      }
      toast(result.ok ? "Test passed" : result.error, result.ok ? "success" : "danger");
    } catch (err) {
      toast(err.message, "danger");
    } finally {
      testButton.disabled = false;
    }
  });

  const resolveRun = document.getElementById("resolve-run");
  if (resolveRun) {
    resolveRun.addEventListener("click", async () => {
      const modal = document.getElementById("resolveModal");
      const providerId = modal.dataset.providerId;
      const channelId = Number(document.getElementById("resolve-channel").value);
      const output = document.getElementById("resolve-output");
      output.innerHTML = '<div class="text-secondary">Resolving...</div>';
      try {
        const result = await api(`/api/providers/${providerId}/test-resolve`, {
          method: "POST",
          body: json({ channel_id: channelId }),
        });
        const report = result.report || {};
        output.innerHTML = `
          <div class="alert ${result.ok ? "alert-success" : "alert-danger"} mb-0">
            <div>Source reachable: <strong>${report.source_reachable ? "YES" : "NO"}</strong></div>
            ${result.ok ? `
              <div>Video codec: ${escapeHtml(report.video_codec || "-")}</div>
              <div>Audio codec: ${escapeHtml(report.audio_codec || "-")}</div>
              <div>Resolution: ${escapeHtml(report.resolution || "-")}</div>
              <div class="text-break">URL: <code>${escapeHtml((result.stream || {}).url || "")}</code></div>
            ` : `<div>${escapeHtml(result.error || "")}</div>`}
          </div>`;
      } catch (err) {
        output.innerHTML = `<div class="alert alert-danger mb-0">${escapeHtml(err.message)}</div>`;
      }
    });
  }

  // ---------------------------------------------------------- debug page
  const debugButton = document.getElementById("run-debug");
  if (debugButton) {
    debugButton.addEventListener("click", async () => {
      const host = document.getElementById("debug-output");
      debugButton.disabled = true;
      host.innerHTML = '<div class="card"><div class="card-body text-secondary">Running...</div></div>';
      try {
        const result = await api(`/api/providers/${debugButton.dataset.id}/debug`);
        if (!result.ok) {
          host.innerHTML = `<div class="alert alert-danger">${escapeHtml(result.error)}</div>`;
          return;
        }
        const report = result.report || {};
        const steps = (report.steps || [])
          .map(
            (step) => `
          <tr>
            <td>${escapeHtml(step.name)}</td>
            <td>${step.ok ? '<span class="badge text-bg-success">OK</span>' : '<span class="badge text-bg-danger">FAILED</span>'}</td>
            <td>${escapeHtml(step.status || "-")}</td>
            <td>${escapeHtml(step.content_type || "-")}</td>
            <td class="text-break">${escapeHtml(step.detail || "")}</td>
          </tr>
          ${step.preview ? `<tr><td colspan="5"><pre class="json-preview mb-0">${escapeHtml(step.preview)}</pre></td></tr>` : ""}`
          )
          .join("");
        const cookies = (report.cookies || [])
          .map((cookie) => `<li>${escapeHtml(cookie.name)} = <span class="text-secondary">***</span> <span class="smaller">(${escapeHtml(cookie.domain || "")})</span></li>`)
          .join("");
        host.innerHTML = `
          <div class="card mb-3">
            <div class="card-header">Request context</div>
            <div class="card-body smaller">
              <div>Base URL: <code>${escapeHtml(report.base_url || "")}</code></div>
              <div>Auth type: ${escapeHtml(report.auth_type || "")}</div>
              <div>Headers sent: <pre class="json-preview mb-0">${escapeHtml(json(report.request_headers || {}))}</pre></div>
            </div>
          </div>
          <div class="card mb-3">
            <div class="card-header">Steps</div>
            <div class="table-responsive">
              <table class="table table-sm mb-0 smaller">
                <thead><tr><th>Step</th><th>Result</th><th>HTTP</th><th>Content type</th><th>Detail</th></tr></thead>
                <tbody>${steps || '<tr><td colspan="5">No steps.</td></tr>'}</tbody>
              </table>
            </div>
          </div>
          <div class="card">
            <div class="card-header">Cookies received</div>
            <div class="card-body smaller">
              ${cookies ? `<ul class="mb-0">${cookies}</ul>` : '<span class="text-secondary">none</span>'}
              ${report.channel_count !== undefined ? `<div class="mt-2">Channels parsed: <strong>${escapeHtml(report.channel_count)}</strong></div>` : ""}
            </div>
          </div>`;
      } catch (err) {
        host.innerHTML = `<div class="alert alert-danger">${escapeHtml(err.message)}</div>`;
      } finally {
        debugButton.disabled = false;
      }
    });
  }

  // ---------------------------------------------------------- settings page
  const settingsForm = document.getElementById("settings-form");
  if (settingsForm) {
    settingsForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = formData(settingsForm);
      const payload = { values: {} };
      Object.entries(data).forEach(([key, value]) => {
        if (key === "telegram_bot_token") {
          if (value) {
            payload.telegram_bot_token = value;
          }
          return;
        }
        if (key === "admin_password") {
          if (value) {
            payload.admin_password = value;
          }
          return;
        }
        payload.values[key] = value;
      });
      try {
        const result = await api("/api/settings", { method: "POST", body: json(payload) });
        if (result.ok) {
          toast("Settings saved", "success");
          setTimeout(() => window.location.reload(), 800);
        } else {
          Object.entries(result.errors || {}).forEach(([key, message]) =>
            toast(`${key}: ${message}`, "danger")
          );
        }
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }

  const telegramTest = document.getElementById("telegram-test");
  if (telegramTest) {
    telegramTest.addEventListener("click", async () => {
      const host = document.getElementById("telegram-result") || document.getElementById("setup-result");
      telegramTest.disabled = true;
      try {
        const result = await api("/api/telegram/test", { method: "POST" });
        const message = result.ok ? "Message sent" : result.error || "failed";
        if (host) {
          host.innerHTML = `<span class="${result.ok ? "text-success" : "text-danger"}">${escapeHtml(message)}</span>`;
        }
        toast(message, result.ok ? "success" : "danger");
      } catch (err) {
        toast(err.message, "danger");
      } finally {
        telegramTest.disabled = false;
      }
    });
  }

  const importButton = document.getElementById("import-btn");
  const importFile = document.getElementById("import-file");
  if (importButton && importFile) {
    importButton.addEventListener("click", () => importFile.click());
    importFile.addEventListener("change", async () => {
      const file = importFile.files[0];
      if (!file) {
        return;
      }
      try {
        const text = await file.text();
        const result = await api("/api/config/import", {
          method: "POST",
          body: json({ data: JSON.parse(text) }),
        });
        const report = result.report || {};
        toast(
          `Imported ${report.channels || 0} channels, ${report.providers || 0} providers`,
          result.ok ? "success" : "warning"
        );
        (report.errors || []).forEach((message) => toast(message, "danger"));
        setTimeout(() => window.location.reload(), 1200);
      } catch (err) {
        toast(err.message, "danger");
      } finally {
        importFile.value = "";
      }
    });
  }

  // ------------------------------------------------------------- setup page
  const setupForm = document.getElementById("setup-form");
  if (setupForm) {
    setupForm.addEventListener("submit", async (event) => {
      event.preventDefault();
      const data = formData(setupForm);
      const payload = {
        values: {
          default_rtmp_server: data.default_rtmp_server || "",
          telegram_chat_id: data.telegram_chat_id || "",
        },
      };
      if (data.telegram_bot_token) {
        payload.telegram_bot_token = data.telegram_bot_token;
      }
      try {
        const result = await api("/api/settings", { method: "POST", body: json(payload) });
        if (result.ok) {
          toast("Saved", "success");
          window.location.href = "/";
        } else {
          Object.entries(result.errors || {}).forEach(([key, message]) =>
            toast(`${key}: ${message}`, "danger")
          );
        }
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }

  const ffmpegTest = document.getElementById("ffmpeg-test");
  if (ffmpegTest) {
    ffmpegTest.addEventListener("click", async () => {
      const host = document.getElementById("setup-result");
      try {
        const status = await api("/api/status");
        const ok = status.ffmpeg.available && status.ffprobe.available;
        host.innerHTML = `<div class="${ok ? "text-success" : "text-danger"}">
          ${escapeHtml(status.ffmpeg.version || status.ffmpeg.error)}<br>
          ${escapeHtml(status.ffprobe.version || status.ffprobe.error)}
        </div>`;
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }

  const loginTest = document.getElementById("login-test");
  if (loginTest) {
    loginTest.addEventListener("click", async () => {
      const host = document.getElementById("setup-result");
      try {
        const result = await api("/api/test-login", { method: "POST", body: json({}) });
        host.innerHTML = `<div class="${result.ok ? "text-success" : "text-danger"}">
          ${escapeHtml(result.ok ? result.message || "Login Successful" : result.error)}
        </div>`;
      } catch (err) {
        toast(err.message, "danger");
      }
    });
  }
})();
