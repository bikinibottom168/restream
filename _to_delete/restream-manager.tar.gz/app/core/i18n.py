"""Interface language.

A deliberately small translation layer: the English string in the template *is*
the lookup key, so an untranslated string still renders correctly instead of
showing a raw key like ``nav.dashboard``.

    {{ t('Dashboard') }}   ->  'แดชบอร์ด'   when the language is Thai
                           ->  'Dashboard'  when it is English, or when the
                                            phrase has no translation yet

The language is one application-wide setting (``ui_language``) rather than a
per-request negotiation, because this dashboard has a single operator.
"""

from __future__ import annotations

from typing import Callable

DEFAULT_LANGUAGE = "th"

#: code -> label shown in the switcher
LANGUAGES: dict[str, str] = {
    "en": "English",
    "th": "ไทย",
}

#: English source string -> Thai. Anything missing falls back to English.
THAI: dict[str, str] = {
    # ---- navigation ---------------------------------------------------
    "Dashboard": "แดชบอร์ด",
    "Providers": "แหล่งสัญญาณ",
    "Events": "เหตุการณ์",
    "History": "ประวัติการล่ม",
    "Logs": "บันทึก",
    "Settings": "ตั้งค่า",
    "Setup": "ตั้งค่าเริ่มต้น",
    "Language": "ภาษา",
    # ---- status chrome ------------------------------------------------
    "OK": "พร้อม",
    "MISSING": "ไม่พบ",
    "ON": "เปิด",
    "OFF": "ปิด",
    "Startup warnings": "คำเตือนตอนเริ่มระบบ",
    # ---- summary cards ------------------------------------------------
    "Total": "ทั้งหมด",
    "Online": "ออนไลน์",
    "Offline": "ออฟไลน์",
    "Reconnecting": "กำลังเชื่อมต่อใหม่",
    "Disabled": "ปิดใช้งาน",
    # ---- system stats -------------------------------------------------
    "CPU": "ซีพียู",
    "RAM": "หน่วยความจำ",
    "FFmpeg processes": "จำนวน FFmpeg",
    "App uptime": "เวลาทำงานของระบบ",
    "System metrics unavailable on this host.": "เครื่องนี้อ่านค่าระบบไม่ได้",
    # ---- dashboard toolbar --------------------------------------------
    "Channels": "ช่องสัญญาณ",
    "Sync Channels": "ซิงก์รายการช่อง",
    "Start All": "เริ่มทั้งหมด",
    "Stop All": "หยุดทั้งหมด",
    "Restart Selected": "รีสตาร์ตที่เลือก",
    "Refresh Selected": "รีเฟรช URL ที่เลือก",
    "Bulk Add": "เพิ่มทีละหลายช่อง",
    "Add Channel": "เพิ่มช่อง",
    "Search channel...": "ค้นหาช่อง...",
    "All": "ทั้งหมด",
    "Filter": "กรอง",
    # ---- channel table ------------------------------------------------
    "Channel": "ช่อง",
    "Status": "สถานะ",
    "Source": "ต้นทาง",
    "RTMP": "ปลายทาง RTMP",
    "Uptime": "เวลาออนไลน์",
    "Bitrate": "บิตเรต",
    "Last check": "ตรวจล่าสุด",
    "Restarts": "รีสตาร์ต",
    "Actions": "การจัดการ",
    "No channels match this filter.": "ไม่มีช่องที่ตรงกับตัวกรองนี้",
    "Configure a provider": "ตั้งค่าแหล่งสัญญาณ",
    # ---- actions ------------------------------------------------------
    "Start": "เริ่ม",
    "Stop": "หยุด",
    "Restart": "รีสตาร์ต",
    "Refresh source": "รีเฟรช URL ต้นทาง",
    "Refresh Source": "รีเฟรช URL ต้นทาง",
    "Test Source": "ทดสอบต้นทาง",
    "Details": "รายละเอียด",
    "Edit": "แก้ไข",
    "Delete": "ลบ",
    "Enable": "เปิดใช้งาน",
    "Disable": "ปิดใช้งาน",
    "Save": "บันทึก",
    "Cancel": "ยกเลิก",
    "Create": "สร้าง",
    "Preview": "ดูตัวอย่าง",
    "Close": "ปิด",
    # ---- channel detail -----------------------------------------------
    "Input": "ขาเข้า",
    "Output": "ขาออก",
    "Provider": "แหล่งสัญญาณ",
    "Provider channel id": "รหัสช่องของแหล่งสัญญาณ",
    "Endpoint URL": "URL ปลายทางที่ใช้ดึง",
    "Current source": "URL ต้นทางปัจจุบัน",
    "Last refresh": "รีเฟรชล่าสุด",
    "Expires": "หมดอายุ",
    "Resolve count": "จำนวนครั้งที่ดึง URL",
    "Source status": "สถานะต้นทาง",
    "RTMP destination": "ปลายทาง RTMP",
    "Mode": "โหมด",
    "FFmpeg status": "สถานะ FFmpeg",
    "FFmpeg PID": "FFmpeg PID",
    "Output time": "เวลาที่ส่งออก",
    "Speed": "ความเร็ว",
    "Last progress": "ความคืบหน้าล่าสุด",
    "Started": "เริ่มเมื่อ",
    "Recent events": "เหตุการณ์ล่าสุด",
    "All events": "ดูทั้งหมด",
    "Downtime history": "ประวัติการล่ม",
    "Full history": "ดูประวัติทั้งหมด",
    "FFmpeg log (tail)": "บันทึก FFmpeg (ท้ายไฟล์)",
    "Open log viewer": "เปิดหน้าบันทึก",
    "Last error:": "ข้อผิดพลาดล่าสุด:",
    "running": "กำลังทำงาน",
    "stopped": "หยุดอยู่",
    "not configured": "ยังไม่ได้ตั้งค่า",
    "ago": "ที่แล้ว",
    # ---- providers page -----------------------------------------------
    "Add Provider": "เพิ่มแหล่งสัญญาณ",
    "Examples": "ตัวอย่าง",
    "Use this example": "ใช้ตัวอย่างนี้",
    "Fill in the example": "เติมค่าตัวอย่าง",
    "Show it as text": "ดูแบบข้อความ",
    "Test Authentication": "ทดสอบการเข้าสู่ระบบ",
    "Test Channel List": "ทดสอบรายการช่อง",
    "Test Stream Resolver": "ทดสอบการดึง URL",
    "Debug": "ตรวจสอบปัญหา",
    "Credentials": "ข้อมูลเข้าสู่ระบบ",
    "Configuration": "การตั้งค่า",
    "Provider name": "ชื่อแหล่งสัญญาณ",
    "Provider type": "ประเภท",
    "Authentication": "การยืนยันตัวตน",
    "Base URL": "Base URL",
    "Username": "ชื่อผู้ใช้",
    "Password": "รหัสผ่าน",
    "API token": "API token",
    "Cookie": "Cookie",
    "Enabled": "เปิดใช้งาน",
    "Default": "ค่าเริ่มต้น",
    "Discovery": "ดึงรายการช่องได้",
    "supported": "รองรับ",
    "not available": "ไม่รองรับ",
    "No providers yet.": "ยังไม่มีแหล่งสัญญาณ",
    "Save provider": "บันทึกแหล่งสัญญาณ",
    "Edit raw JSON": "แก้ไข JSON โดยตรง",
    # ---- events / history / logs --------------------------------------
    "Time": "เวลา",
    "Event": "เหตุการณ์",
    "Message": "ข้อความ",
    "All channels": "ทุกช่อง",
    "Select channel": "เลือกช่อง",
    "No events recorded yet.": "ยังไม่มีเหตุการณ์",
    "Down at": "ล่มเมื่อ",
    "Recovered at": "กลับมาเมื่อ",
    "Downtime": "ระยะเวลาที่ล่ม",
    "Cause": "สาเหตุ",
    "Attempts": "จำนวนครั้งที่ลอง",
    "Outages": "จำนวนครั้งที่ล่ม",
    "Total downtime": "รวมเวลาที่ล่ม",
    "Last 7 days": "7 วันล่าสุด",
    "No outages recorded.": "ยังไม่มีประวัติการล่ม",
    "ongoing": "ยังล่มอยู่",
    "Application": "ระบบ",
    "Show": "แสดง",
    "Nothing logged yet.": "ยังไม่มีบันทึก",
    "lines": "บรรทัด",
    # ---- settings ------------------------------------------------------
    "Monitoring": "การตรวจสอบ",
    "Recovery": "การกู้คืน",
    "Streaming": "การสตรีม",
    "Binaries": "โปรแกรมที่ใช้",
    "Telegram": "Telegram",
    "Security & privacy": "ความปลอดภัยและความเป็นส่วนตัว",
    "Save settings": "บันทึกการตั้งค่า",
    "Export Configuration": "ส่งออกการตั้งค่า",
    "Import Configuration": "นำเข้าการตั้งค่า",
    "Send Test Message": "ส่งข้อความทดสอบ",
    "Bot token": "Bot token",
    "Chat id": "Chat id",
    "Default RTMP server": "RTMP server หลัก",
    "Default stream mode": "โหมดสตรีมเริ่มต้น",
    "FFmpeg path": "ตำแหน่ง FFmpeg",
    "ffprobe path": "ตำแหน่ง ffprobe",
    "Dashboard password": "รหัสผ่านแดชบอร์ด",
    # ---- bulk add ------------------------------------------------------
    "Bulk add channels": "เพิ่มช่องทีละหลายรายการ",
    "Create channels": "สร้างช่องทั้งหมด",
    "Load JSON file": "โหลดไฟล์ JSON",
    "Stream key prefix": "คำนำหน้า stream key",
    "Stream mode": "โหมดสตรีม",
    "Name": "ชื่อ",
    "Type": "ประเภท",
    "Key": "Key",
    # ---- channel form --------------------------------------------------
    "Source URL (media)": "URL ต้นทาง (ไฟล์สื่อโดยตรง)",
    "Source endpoint URL": "URL ปลายทางที่ใช้ดึง",
    "RTMP URL (full)": "RTMP URL (แบบเต็ม)",
    "Stream key": "Stream key",
    "Auto start": "เริ่มอัตโนมัติ",
    "Logo URL": "URL โลโก้",
    "Group": "กลุ่ม",
    "Playback Referer": "Referer ตอนเล่น",
    "Playback User-Agent": "User-Agent ตอนเล่น",
    "Copy": "คัดลอก",
}

TRANSLATIONS: dict[str, dict[str, str]] = {"th": THAI}


def normalise(code: str | None) -> str:
    """Return a supported language code, defaulting when unknown."""
    value = (code or "").strip().lower()
    return value if value in LANGUAGES else DEFAULT_LANGUAGE


def translate(text: str, language: str = DEFAULT_LANGUAGE) -> str:
    """Look up one phrase, falling back to the English source."""
    table = TRANSLATIONS.get(normalise(language))
    if not table:
        return text
    return table.get(text, text)


def make_translator(language: str) -> Callable[[str], str]:
    """Return a ``t(text)`` bound to *language*, for use as a Jinja global."""
    code = normalise(language)
    table = TRANSLATIONS.get(code, {})

    def _t(text: str) -> str:
        return table.get(text, text)

    return _t


def coverage(language: str = "th") -> float:
    """Fraction of known phrases translated - used by the test suite."""
    table = TRANSLATIONS.get(normalise(language), {})
    if not table:
        return 0.0
    translated = sum(1 for key, value in table.items() if value and value != key)
    return translated / len(table)
