"""Per-channel supervisor.

One :class:`StreamSupervisor` per channel, each owning one ``asyncio.Task`` and
one FFmpeg process.  Channels are fully independent: a failure in one never
stops, restarts or re-resolves another.

    START
      |
      v
    resolve source (provider-agnostic)
      |
      v
    validate with ffprobe
      |
      v
    start FFmpeg  --> confirm output is flowing --> ONLINE
      |                                              |
      |                                    fast process monitor (5 s)
      |                                    deep source check (300 s)
      v                                              |
    RECONNECTING <---------- confirmed failure ------+
      |
      v
    refresh THIS channel's URL, restart FFmpeg, verify, ONLINE
"""

from __future__ import annotations

import asyncio
import logging
import time
from typing import Any

from app.core.state import ChannelState, can_transition
from app.core.settings_store import SettingsStore
from app.core.timeutil import utcnow
from app.database import crud
from app.database.db import run_db
from app.database.models import EventType
from app.providers.resolver import ResolutionOutcome, StreamResolver
from app.streaming.backoff import BackoffPolicy, RestartCircuit
from app.streaming.ffmpeg import FFmpegManager, FFmpegProcess
from app.streaming.orphan import PidRegistry
from app.streaming.probe import probe_stream

logger = logging.getLogger(__name__)

#: Seconds to wait after spawning before deciding FFmpeg survived startup.
STARTUP_GRACE_SECONDS = 6.0
#: Seconds to wait for the first bytes to reach the RTMP endpoint.
OUTPUT_CONFIRM_SECONDS = 20.0


class StreamSupervisor:
    """Own the lifecycle of exactly one channel."""

    def __init__(
        self,
        channel_id: int,
        *,
        resolver: StreamResolver,
        ffmpeg: FFmpegManager,
        settings: SettingsStore,
        notifier: Any,
        pids: PidRegistry,
    ) -> None:
        self.channel_id = channel_id
        self._resolver = resolver
        self._ffmpeg = ffmpeg
        self._settings = settings
        self._notifier = notifier
        self._pids = pids

        self._task: asyncio.Task[None] | None = None
        self._process: FFmpegProcess | None = None
        self._stop_event = asyncio.Event()
        self._wake_event = asyncio.Event()
        self._state = ChannelState.STOPPED
        self._backoff = BackoffPolicy(max_delay=settings.get_int("max_restart_delay_seconds"))
        self._circuit = RestartCircuit(
            window_seconds=settings.get_int("restart_window_seconds"),
            threshold=settings.get_int("restart_window_threshold"),
            throttled_delay=settings.get_int("unstable_restart_delay_seconds"),
        )

        self.channel_name = ""
        self.last_outcome: ResolutionOutcome | None = None
        self.last_error = ""
        self.started_monotonic = 0.0
        self.last_check_at = None
        self.consecutive_failures = 0
        self._force_refresh = False
        self._down_since: float | None = None

    # ------------------------------------------------------------------ #
    # public control surface
    # ------------------------------------------------------------------ #
    @property
    def state(self) -> ChannelState:
        return self._state

    @property
    def is_running(self) -> bool:
        return self._task is not None and not self._task.done()

    @property
    def process(self) -> FFmpegProcess | None:
        return self._process

    async def start(self) -> bool:
        """Start (or resume) the supervisor task. Returns False if already up."""
        if self.is_running:
            return False
        self._stop_event.clear()
        self._backoff.reset()
        self._task = asyncio.create_task(
            self._run(), name=f"supervisor-channel-{self.channel_id}"
        )
        return True

    async def stop(self, reason: str = "stopped by operator") -> None:
        """Stop the channel and its FFmpeg process, and wait for both."""
        self._stop_event.set()
        self._wake_event.set()
        process = self._process
        if process is not None:
            await process.stop(reason)
        task = self._task
        if task is not None and not task.done():
            try:
                await asyncio.wait_for(asyncio.shield(task), timeout=30)
            except asyncio.TimeoutError:
                logger.warning("channel %s: supervisor did not exit, cancelling", self.channel_id)
                task.cancel()
                try:
                    await task
                except (asyncio.CancelledError, Exception):  # noqa: BLE001
                    pass
        self._task = None
        self._process = None
        self._pids.clear(self.channel_id)
        await self._set_state(ChannelState.STOPPED, ffmpeg_pid=None, started_at=None)
        await self._event(EventType.STREAM_STOPPED, reason)

    async def restart(self, reason: str = "restart requested") -> None:
        """Restart this channel only."""
        await self.stop(reason)
        await self._event(EventType.STREAM_RESTART, reason)
        await self.start()

    async def refresh_source(self) -> ResolutionOutcome:
        """Resolve a new URL for this channel and restart it if it changed."""
        channel = await self._load()
        if channel is None:
            return ResolutionOutcome(ok=False, error="channel no longer exists")
        outcome = await self._resolver.refresh(channel)
        self.last_outcome = outcome
        if outcome.ok:
            await self._event(
                EventType.SOURCE_REFRESHED,
                f"new source acquired ({outcome.stream.safe_url() if outcome.stream else ''})",
            )
            if self.is_running:
                await self.restart("source refreshed")
        else:
            await self._event(
                EventType.SOURCE_FAILED, outcome.error, level="error"
            )
        return outcome

    def wake(self) -> None:
        """Interrupt a backoff sleep (used by 'retry now' style actions)."""
        self._wake_event.set()

    def apply_settings(self) -> None:
        """Re-read tunables after the operator saved the settings page."""
        self._backoff = BackoffPolicy(
            max_delay=self._settings.get_int("max_restart_delay_seconds")
        )
        self._circuit.configure(
            window_seconds=self._settings.get_int("restart_window_seconds"),
            threshold=self._settings.get_int("restart_window_threshold"),
            throttled_delay=self._settings.get_int("unstable_restart_delay_seconds"),
        )

    # ------------------------------------------------------------------ #
    # main loop
    # ------------------------------------------------------------------ #
    async def _run(self) -> None:
        try:
            while not self._stop_event.is_set():
                channel = await self._load()
                if channel is None:
                    logger.info("channel %s disappeared - supervisor exiting", self.channel_id)
                    return
                self.channel_name = channel.name

                if not channel.enabled:
                    await self._set_state(ChannelState.DISABLED)
                    return

                rtmp_url = channel.resolved_rtmp(
                    self._settings.get_str("default_rtmp_server")
                )
                if not rtmp_url:
                    await self._set_state(
                        ChannelState.CONFIG_REQUIRED,
                        error="no RTMP destination configured",
                    )
                    logger.info(
                        "channel %s has no RTMP destination - not starting FFmpeg",
                        self.channel_id,
                    )
                    return

                await self._set_state(ChannelState.STARTING)
                outcome = await self._resolve(channel)
                if outcome is None:
                    return  # unsupported / fatal, already reported
                if not outcome.ok:
                    if await self._handle_failure(outcome.error or "source unavailable"):
                        continue
                    return

                started = await self._launch(channel, outcome, rtmp_url)
                if not started:
                    if await self._handle_failure(self.last_error or "ffmpeg failed to start"):
                        continue
                    return

                reason = await self._monitor()
                await self._teardown(reason)

                if self._stop_event.is_set():
                    return
                if not await self._handle_failure(reason):
                    return
        except asyncio.CancelledError:  # pragma: no cover - shutdown path
            await self._teardown("supervisor cancelled")
            raise
        except Exception as exc:  # noqa: BLE001 - never let a channel task die silently
            logger.exception("channel %s: supervisor crashed", self.channel_id)
            await self._set_state(ChannelState.ERROR, error=str(exc))
            await self._event(EventType.SYSTEM_ERROR, str(exc), level="error")
            await self._notify_system_error(f"supervisor for {self.channel_name}: {exc}")

    # ------------------------------------------------------------------ #
    async def _resolve(self, channel: Any) -> ResolutionOutcome | None:
        """Resolve the source. Returns ``None`` when the channel must stop."""
        outcome = await self._resolver.resolve(channel, force=self._force_refresh)
        self._force_refresh = False
        self.last_outcome = outcome

        if outcome.unsupported:
            await self._set_state(ChannelState.UNSUPPORTED, error=outcome.error)
            await self._event(
                EventType.SOURCE_UNSUPPORTED, outcome.error, level="error"
            )
            logger.warning(
                "channel %s marked UNSUPPORTED: %s", self.channel_id, outcome.error
            )
            return None

        if outcome.auth_error:
            await self._event(
                EventType.PROVIDER_AUTH_FAILED, outcome.error, level="error"
            )
            await self._notify_auth_error(outcome.error)
        elif not outcome.ok:
            await self._event(EventType.SOURCE_FAILED, outcome.error, level="warning")
        return outcome

    async def _launch(
        self, channel: Any, outcome: ResolutionOutcome, rtmp_url: str
    ) -> bool:
        """Spawn FFmpeg and confirm output actually starts flowing."""
        assert outcome.stream is not None
        mode = channel.stream_mode or self._settings.get_str("default_stream_mode")
        try:
            process = await self._ffmpeg.spawn(
                self.channel_id,
                stream=outcome.stream,
                output_url=rtmp_url,
                mode=mode,
                probe=outcome.probe,
                video_bitrate=self._settings.get_str("transcode_video_bitrate"),
                audio_bitrate=self._settings.get_str("transcode_audio_bitrate"),
                preset=self._settings.get_str("transcode_preset"),
            )
        except FileNotFoundError:
            message = (
                f"ffmpeg not found at {self._settings.get_str('ffmpeg_path')!r}; "
                "check the FFmpeg path on the settings page"
            )
            self.last_error = message
            await self._set_state(ChannelState.ERROR, error=message)
            await self._event(EventType.SYSTEM_ERROR, message, level="error")
            return False
        except OSError as exc:
            self.last_error = f"could not start ffmpeg: {exc}"
            await self._set_state(ChannelState.OFFLINE, error=self.last_error)
            return False

        self._process = process
        if process.pid is not None:
            self._pids.record(self.channel_id, process.pid, process.command)

        # Did it survive startup at all?
        if not await self._survives_startup(process):
            self.last_error = process.last_error or "ffmpeg exited immediately"
            await self._set_state(ChannelState.OFFLINE, error=self.last_error)
            await self._event(
                EventType.STREAM_DOWN,
                f"ffmpeg exited during startup: {self.last_error}",
                level="error",
            )
            return False

        # Is data actually reaching the RTMP endpoint?
        if not await self._confirm_output(process):
            self.last_error = (
                process.last_error or "no data reached the RTMP destination"
            )
            await self._set_state(ChannelState.OFFLINE, error=self.last_error)
            return False

        self.started_monotonic = time.monotonic()
        await self._set_state(
            ChannelState.ONLINE,
            ffmpeg_pid=process.pid,
            started_at=utcnow(),
            error="",
        )
        await self._event(
            EventType.STREAM_STARTED,
            f"relaying to {rtmp_url.rsplit('/', 1)[0]}/*** in {mode} mode",
        )
        await self._announce_recovery()
        self._backoff.reset()
        self.consecutive_failures = 0
        return True

    async def _survives_startup(self, process: FFmpegProcess) -> bool:
        deadline = time.monotonic() + STARTUP_GRACE_SECONDS
        while time.monotonic() < deadline:
            if self._stop_event.is_set():
                return False
            if not process.running:
                return False
            await asyncio.sleep(0.5)
        return process.running

    async def _confirm_output(self, process: FFmpegProcess) -> bool:
        """Wait until FFmpeg reports progress, i.e. the output is live.

        This is the RTMP verification step: FFmpeg only advances ``out_time``
        once the muxer has accepted data, so a refused or wrong RTMP endpoint
        shows up here instead of looking 'online' forever.
        """
        deadline = time.monotonic() + OUTPUT_CONFIRM_SECONDS
        while time.monotonic() < deadline:
            if self._stop_event.is_set():
                return False
            if not process.running:
                return False
            if process.metrics.out_time_us > 0 or process.metrics.total_size > 0:
                return True
            await asyncio.sleep(0.5)
        logger.warning(
            "channel %s: no output progress within %.0fs",
            self.channel_id,
            OUTPUT_CONFIRM_SECONDS,
        )
        return False

    # ------------------------------------------------------------------ #
    async def _monitor(self) -> str:
        """Watch the running stream. Returns the reason it needs restarting."""
        process = self._process
        if process is None:
            return "ffmpeg process missing"

        monitor_interval = max(1, self._settings.get_int("process_monitor_interval_seconds"))
        deep_interval = max(30, self._settings.get_int("check_interval_seconds"))
        stall_timeout = self._settings.get_int("stall_timeout_seconds")
        threshold = max(1, self._settings.get_int("failure_threshold"))
        next_deep_check = time.monotonic() + deep_interval
        self.consecutive_failures = 0

        while True:
            try:
                await asyncio.wait_for(self._stop_event.wait(), timeout=monitor_interval)
                return "stopped by operator"
            except asyncio.TimeoutError:
                pass

            # ---- fast checks (every few seconds) -----------------------
            if not process.running:
                code = process.returncode
                detail = process.last_error or process.exit_reason or ""
                return f"ffmpeg exited (code {code}) {detail}".strip()

            if process.is_stalled(stall_timeout):
                await self._event(
                    EventType.STREAM_STALLED,
                    f"no output progress for {stall_timeout}s",
                    level="warning",
                )
                return f"stream stalled (no progress for {stall_timeout}s)"

            stream = self.last_outcome.stream if self.last_outcome else None
            if stream is not None and stream.is_expired:
                return "source URL expired"

            # ---- deep source check (every check_interval) --------------
            if time.monotonic() >= next_deep_check:
                next_deep_check = time.monotonic() + deep_interval
                healthy = await self._deep_check(stream)
                if healthy:
                    self.consecutive_failures = 0
                    if self._state is ChannelState.DEGRADED:
                        await self._set_state(ChannelState.ONLINE, error="")
                else:
                    self.consecutive_failures += 1
                    logger.info(
                        "channel %s: source check failed (%d/%d)",
                        self.channel_id,
                        self.consecutive_failures,
                        threshold,
                    )
                    if self.consecutive_failures >= threshold:
                        return (
                            f"source unreachable after {self.consecutive_failures} "
                            "consecutive checks"
                        )
                    await self._set_state(
                        ChannelState.DEGRADED,
                        error=self.last_error or "source check failed",
                    )

    async def _deep_check(self, stream: Any) -> bool:
        """One ffprobe against the current source URL."""
        if stream is None:
            return True  # nothing to check against; the process monitor governs
        result = await probe_stream(
            stream.url,
            ffprobe_path=self._settings.get_str("ffprobe_path"),
            timeout=float(self._settings.get_int("probe_timeout_seconds")),
            headers=stream.request_headers() or None,
            user_agent=stream.user_agent,
        )
        self.last_check_at = utcnow()
        await run_db(crud.update_channel, self.channel_id, last_check_at=self.last_check_at)
        if not result.ok:
            self.last_error = result.error
        return result.ok

    # ------------------------------------------------------------------ #
    async def _teardown(self, reason: str) -> None:
        process = self._process
        if process is not None:
            await process.stop(reason)
            self._pids.clear(self.channel_id)
        self._process = None

    async def _handle_failure(self, reason: str) -> bool:
        """Record the outage, notify once, wait, and say whether to retry."""
        self.last_error = reason
        if self._stop_event.is_set():
            return False

        channel = await self._load()
        if channel is None or not channel.enabled:
            await self._set_state(ChannelState.STOPPED)
            return False

        await self._set_state(ChannelState.RECONNECTING, error=reason)
        await run_db(crud.increment_restart_count, self.channel_id)

        if self._down_since is None:
            self._down_since = time.monotonic()
            await run_db(
                crud.open_downtime, self.channel_id, self.channel_name, reason
            )
            await self._event(EventType.STREAM_DOWN, reason, level="error")
            await self._notify_down(reason)
        else:
            await run_db(crud.bump_downtime_attempts, self.channel_id)

        # Restart-loop protection.
        self._circuit.record_restart()
        if self._circuit.tripped:
            delay = self._circuit.throttled_delay
            if self._circuit.should_notify():
                message = (
                    f"{self._circuit.restarts_in_window} restarts in "
                    f"{self._settings.get_int('restart_window_seconds') // 60} minutes"
                )
                await self._event(EventType.CHANNEL_UNSTABLE, message, level="warning")
                await self._notify_unstable(message)
        else:
            delay = self._backoff.next_delay()

        # The next attempt must ask the provider for a brand-new URL.
        self._force_refresh = True

        logger.info(
            "channel %s: retrying in %.0fs (%s)", self.channel_id, delay, reason
        )
        await self._sleep(delay)
        if self._stop_event.is_set():
            return False
        await self._set_state(ChannelState.RECONNECTING)
        return True

    async def _sleep(self, seconds: float) -> None:
        """Interruptible sleep - stop() or wake() cut it short."""
        self._wake_event.clear()
        waiters = [
            asyncio.create_task(self._stop_event.wait()),
            asyncio.create_task(self._wake_event.wait()),
        ]
        try:
            done, pending = await asyncio.wait(
                waiters, timeout=max(0.0, seconds), return_when=asyncio.FIRST_COMPLETED
            )
            for task in pending:
                task.cancel()
        finally:
            for task in waiters:
                if not task.done():
                    task.cancel()

    # ------------------------------------------------------------------ #
    # state / persistence / notifications
    # ------------------------------------------------------------------ #
    async def _load(self) -> Any:
        return await run_db(crud.get_channel, self.channel_id)

    async def _set_state(
        self,
        state: ChannelState,
        *,
        error: str | None = None,
        ffmpeg_pid: int | None = ...,  # type: ignore[assignment]
        started_at: Any = ...,
    ) -> None:
        if not can_transition(self._state, state):
            logger.debug(
                "channel %s: unusual transition %s -> %s",
                self.channel_id,
                self._state.value,
                state.value,
            )
        previous = self._state
        self._state = state
        if error is not None:
            self.last_error = error
        kwargs: dict[str, Any] = {"last_error": error if error is not None else None}
        if ffmpeg_pid is not ...:
            kwargs["ffmpeg_pid"] = ffmpeg_pid
        if started_at is not ...:
            kwargs["started_at"] = started_at
        await run_db(crud.set_channel_status, self.channel_id, state, **kwargs)
        if previous is not state:
            logger.info(
                "channel %s: %s -> %s", self.channel_id, previous.value, state.value
            )

    async def _announce_recovery(self) -> None:
        if self._down_since is None:
            return
        downtime = time.monotonic() - self._down_since
        record = await run_db(crud.close_downtime, self.channel_id)
        attempts = (record.attempts + 1) if record is not None else 1
        self._down_since = None
        self._circuit.reset()
        await self._event(
            EventType.STREAM_RECOVERED,
            f"recovered after {int(downtime)}s and {attempts} attempt(s)",
        )
        await self._notify_recovered(downtime, attempts)

    async def _event(self, event_type: str, message: str, level: str = "info") -> None:
        try:
            await run_db(
                crud.add_event,
                event_type=event_type,
                message=message,
                channel_id=self.channel_id,
                channel_name=self.channel_name,
                level=level,
            )
        except Exception:  # noqa: BLE001 - logging must not break the stream
            logger.exception("could not record event for channel %s", self.channel_id)

    async def _notify_down(self, reason: str) -> None:
        if self._notifier is None:
            return
        try:
            await self._notifier.channel_down(self.channel_id, self.channel_name, reason)
        except Exception:  # noqa: BLE001
            logger.exception("telegram notification failed (down)")

    async def _notify_recovered(self, downtime: float, attempts: int) -> None:
        if self._notifier is None:
            return
        try:
            await self._notifier.channel_recovered(
                self.channel_id, self.channel_name, downtime, attempts
            )
        except Exception:  # noqa: BLE001
            logger.exception("telegram notification failed (recovered)")

    async def _notify_unstable(self, message: str) -> None:
        if self._notifier is None:
            return
        try:
            await self._notifier.channel_unstable(
                self.channel_id, self.channel_name, message
            )
        except Exception:  # noqa: BLE001
            logger.exception("telegram notification failed (unstable)")

    async def _notify_auth_error(self, error: str) -> None:
        if self._notifier is None:
            return
        try:
            await self._notifier.provider_auth_error(error)
        except Exception:  # noqa: BLE001
            logger.exception("telegram notification failed (auth)")

    async def _notify_system_error(self, error: str) -> None:
        if self._notifier is None:
            return
        try:
            await self._notifier.system_error(error)
        except Exception:  # noqa: BLE001
            logger.exception("telegram notification failed (system)")

    # ------------------------------------------------------------------ #
    def snapshot(self) -> dict[str, Any]:
        """Live runtime view for the dashboard and the API."""
        process = self._process
        stream = self.last_outcome.stream if self.last_outcome else None
        return {
            "channel_id": self.channel_id,
            "state": self._state.value,
            "supervisor_running": self.is_running,
            "uptime_seconds": (
                round(time.monotonic() - self.started_monotonic, 1)
                if self.started_monotonic and self._state.is_running
                else 0
            ),
            "ffmpeg": process.describe() if process else None,
            "consecutive_failures": self.consecutive_failures,
            "restarts_in_window": self._circuit.restarts_in_window,
            "unstable": self._circuit.tripped,
            "backoff_attempt": self._backoff.attempt,
            "last_error": self.last_error,
            "source_url": stream.safe_url() if stream else "",
            "source_expires_at": (
                stream.expires_at.isoformat() if stream and stream.expires_at else None
            ),
            "probe": (
                self.last_outcome.probe.as_dict()
                if self.last_outcome and self.last_outcome.probe
                else None
            ),
        }
