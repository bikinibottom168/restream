@echo off
REM ===========================================================================
REM Restream Manager - first-time setup for Windows 10/11
REM Creates a virtual environment, installs dependencies and checks FFmpeg.
REM ===========================================================================
setlocal enabledelayedexpansion
cd /d "%~dp0"

echo.
echo ==========================================
echo   Restream Manager - Windows setup
echo ==========================================
echo.

REM ---- 1. Python ------------------------------------------------------------
where python >nul 2>&1
if errorlevel 1 (
    echo [ERROR] Python was not found on PATH.
    echo         Install Python 3.11 or newer from https://www.python.org/downloads/
    echo         and tick "Add python.exe to PATH" during installation.
    pause
    exit /b 1
)

for /f "tokens=2" %%v in ('python --version 2^>^&1') do set PYVER=%%v
echo [OK] Python %PYVER% found.

python -c "import sys; sys.exit(0 if sys.version_info >= (3,11) else 1)"
if errorlevel 1 (
    echo [ERROR] Python 3.11 or newer is required. Found %PYVER%.
    pause
    exit /b 1
)

REM ---- 2. virtual environment ----------------------------------------------
if not exist ".venv" (
    echo [..] Creating virtual environment in .venv
    python -m venv .venv
    if errorlevel 1 (
        echo [ERROR] Could not create the virtual environment.
        pause
        exit /b 1
    )
) else (
    echo [OK] Virtual environment already exists.
)

call .venv\Scripts\activate.bat

REM ---- 3. dependencies ------------------------------------------------------
echo [..] Upgrading pip
python -m pip install --upgrade pip --quiet

echo [..] Installing dependencies (this can take a minute)
python -m pip install -r requirements.txt
if errorlevel 1 (
    echo [ERROR] Dependency installation failed. See the messages above.
    pause
    exit /b 1
)
echo [OK] Dependencies installed.

REM ---- 4. .env --------------------------------------------------------------
if not exist ".env" (
    copy ".env.example" ".env" >nul
    echo [OK] Created .env from .env.example - open it and fill in your values.
) else (
    echo [OK] .env already exists, leaving it untouched.
)

REM ---- 5. folders -----------------------------------------------------------
if not exist "data" mkdir data
if not exist "logs" mkdir logs
if not exist "logs\ffmpeg" mkdir logs\ffmpeg

REM ---- 6. FFmpeg ------------------------------------------------------------
echo.
where ffmpeg >nul 2>&1
if errorlevel 1 (
    echo [WARN] FFmpeg was not found on PATH.
    echo.
    echo        1. Download a build from https://www.gyan.dev/ffmpeg/builds/
    echo           ^(the "release essentials" zip is enough^)
    echo        2. Extract it, for example to C:\ffmpeg
    echo        3. Either add C:\ffmpeg\bin to your PATH, or set these in .env:
    echo              FFMPEG_PATH=C:\ffmpeg\bin\ffmpeg.exe
    echo              FFPROBE_PATH=C:\ffmpeg\bin\ffprobe.exe
    echo.
    echo        The dashboard will start either way and will tell you FFmpeg is missing.
) else (
    for /f "delims=" %%f in ('where ffmpeg') do set FFPATH=%%f & goto :gotffmpeg
    :gotffmpeg
    echo [OK] FFmpeg found at !FFPATH!
)

where ffprobe >nul 2>&1
if errorlevel 1 (
    echo [WARN] ffprobe was not found on PATH ^(it ships with FFmpeg^).
) else (
    echo [OK] ffprobe found.
)

REM ---- 7. self-check --------------------------------------------------------
echo.
echo [..] Verifying the installation
python -c "import app.main; print('[OK] Application imports cleanly.')"
if errorlevel 1 (
    echo [ERROR] The application could not be imported. See the traceback above.
    pause
    exit /b 1
)

echo.
echo ==========================================
echo   Setup complete
echo ==========================================
echo.
echo   1. Edit .env if you need to change the port or add credentials
echo   2. Start the application with:  run_windows.bat
echo   3. Open http://127.0.0.1:8787
echo.
pause
