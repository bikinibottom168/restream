#!/usr/bin/env bash
# ===========================================================================
# Restream Manager - first-time setup for macOS (Intel and Apple Silicon)
# Creates a virtual environment, installs dependencies and checks FFmpeg.
# ===========================================================================
set -euo pipefail

cd "$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

BOLD=$'\033[1m'; GREEN=$'\033[0;32m'; YELLOW=$'\033[0;33m'; RED=$'\033[0;31m'; RESET=$'\033[0m'
ok()   { printf "%s[OK]%s   %s\n" "$GREEN" "$RESET" "$1"; }
warn() { printf "%s[WARN]%s %s\n" "$YELLOW" "$RESET" "$1"; }
fail() { printf "%s[ERROR]%s %s\n" "$RED" "$RESET" "$1"; exit 1; }
step() { printf "%s[..]%s   %s\n" "$BOLD" "$RESET" "$1"; }

printf "\n%s==========================================%s\n" "$BOLD" "$RESET"
printf "%s  Restream Manager - macOS setup%s\n" "$BOLD" "$RESET"
printf "%s==========================================%s\n\n" "$BOLD" "$RESET"

# ---- 1. Python -------------------------------------------------------------
PYTHON=""
for candidate in python3.13 python3.12 python3.11 python3; do
  if command -v "$candidate" >/dev/null 2>&1; then
    if "$candidate" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 11) else 1)' 2>/dev/null; then
      PYTHON="$candidate"
      break
    fi
  fi
done

if [[ -z "$PYTHON" ]]; then
  fail "Python 3.11+ not found. Install it with:  brew install python@3.12"
fi
ok "Using $($PYTHON --version) at $(command -v "$PYTHON")"

# ---- 2. virtual environment ------------------------------------------------
if [[ ! -d .venv ]]; then
  step "Creating virtual environment in .venv"
  "$PYTHON" -m venv .venv
else
  ok "Virtual environment already exists"
fi

# shellcheck source=/dev/null
source .venv/bin/activate

# ---- 3. dependencies -------------------------------------------------------
step "Upgrading pip"
python -m pip install --upgrade pip --quiet

step "Installing dependencies (this can take a minute)"
python -m pip install -r requirements.txt
ok "Dependencies installed"

# ---- 4. .env ---------------------------------------------------------------
if [[ ! -f .env ]]; then
  cp .env.example .env
  ok "Created .env from .env.example - open it and fill in your values"
else
  ok ".env already exists, leaving it untouched"
fi

# ---- 5. folders ------------------------------------------------------------
mkdir -p data logs/ffmpeg logs/debug data/pids
ok "Data and log directories ready"

# ---- 6. FFmpeg -------------------------------------------------------------
echo
if command -v ffmpeg >/dev/null 2>&1; then
  ok "FFmpeg found: $(ffmpeg -version 2>/dev/null | head -n 1)"
else
  warn "FFmpeg not found."
  echo "       Install it with:  brew install ffmpeg"
  echo "       (Homebrew itself: https://brew.sh)"
  echo "       The dashboard starts either way and will report FFmpeg as missing."
fi

if command -v ffprobe >/dev/null 2>&1; then
  ok "ffprobe found"
else
  warn "ffprobe not found (it ships with FFmpeg)"
fi

# ---- 7. self-check ---------------------------------------------------------
echo
step "Verifying the installation"
python -c "import app.main" && ok "Application imports cleanly"

# ---- 8. make the launcher executable ---------------------------------------
chmod +x run_macos.command run_macos.sh 2>/dev/null || true

printf "\n%s==========================================%s\n" "$BOLD" "$RESET"
printf "%s  Setup complete%s\n" "$BOLD" "$RESET"
printf "%s==========================================%s\n\n" "$BOLD" "$RESET"
echo "  1. Edit .env if you need to change the port or add credentials"
echo "  2. Start it with:  ./run_macos.sh   (or double-click run_macos.command)"
echo "  3. Open http://127.0.0.1:8787"
echo
